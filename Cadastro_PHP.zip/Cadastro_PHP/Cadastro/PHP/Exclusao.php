<?php 
    session_start();
    include("conexao.php");

    $nome = $_POST['Nome'];
    $Senha = $_POST['Senha'];
    $confirma = $_POST['confirma'];
    $ID = $_POST['ID'];

    if ( empty ( $nome || $Senha || $confirma || $ID) ) {
        header("Location: \Cadastro\excluir.html");
        exit;

    }elseif ( $Senha == $confirma ) {
        $sql = "DELETE FROM `cadastro` WHERE `Nome` = '$nome' AND `Senha` = '$Senha' AND `IDusuario` = '$ID'";
        $resultado = mysqli_query ( $conexao,$sql ) or die ("Erro de conexão");

        mysqli_close ( $conexao );
        header("Location: \Cadastro\PHP\sair.php");
        exit;

    }else{
        header("Location: \Cadastro\excluir.html");
        exit;
    }
?>