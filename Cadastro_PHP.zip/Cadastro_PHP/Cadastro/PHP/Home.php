<?php
session_start();
if (!isset($_SESSION['usuario'])) {
    header('Location: index.html');
    exit();
}
?>
<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <link rel="stylesheet" href="./CSS/principal.css">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Home-Page</title>
    <style>
        body{
        margin: 0;
        width: 100vw;
        height: 100vh;
        overflow: hidden;
        background-color: #f2f2f2;
        font-family: system-ui, -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, Oxygen, Ubuntu, Cantarell, 'Open Sans', 'Helvetica Neue', sans-serif;
        }

        a {text-decoration: none;}
        .container {
            margin: auto;
            width: 1000px;
        }
        ul {
            padding-left: 0;
            margin-top: 0;
            margin-bottom: 0;
            list-style: none;
        }
        nav {
            background: #0ca0d6;
            font-size: 0;
            position: relative;
        }

        nav > ul > li {
            display: inline-block;
            font-size: 14px;
            padding: 0 15px;
            position: relative;
        }

        nav > ul > li > a {
            color: #fff;
            display: block;
            padding: 20px 0;
            border-bottom: 3px solid transparent;
            transition: all .3s ease;
        }
        nav > ul > li:hover > a {
            color: #444; 
            border-bottom: 3px solid #444;
        }

        .mega-menu {
            background: #eee;
            visibility: hidden;
            opacity: 0;
            transition: visibility 0s, opacity 0.5s linear;
            position: absolute;
            left: 0;
            width: 100%;
            padding-bottom: 20px;
            border: 1px solid #000;
        }
        .mega-menu h3 {color: #444;}

        .mega-menu .container {
            display: flex;
        }
        .mega-menu .item {
            flex-grow: 1;
            margin: 0 10px;
        }
        .mega-menu .item img {
            width: 100%;
        }
        .mega-menu a {
            border-bottom: 1px solid #ddd;
            color: #4ea3d8;
            display: block;
            padding: 10px 0;
        }
        .mega-menu a:hover {color: #2d6a91;}

        .dropdown {position: static;}

        .dropdown:hover .mega-menu {
            visibility: visible;
            opacity: 1;
        }
        .logo{
            padding-top: 15px;
            text-align: center;
        }
        nav{
            text-align: left;
            border: 1px solid #000;
        }
        footer {
            display: flex;
            align-items: center;
            justify-content: center;
            flex-wrap: wrap;
            padding-top: 20%;
        }
        footer a {
            margin: 5px;
        }
        h6{
            font-size: 15px;
        }
        img{
            height: 23px;
            width: 23px;
        }
        img:hover {
            transform: scale(1.43);
        }
    </style>
</head>
<body>
    <!-- Criado no dia 29 de Setembro -->
    <nav>
        <ul class="container">
            <li><a href="#">Home</a></li>
            <li class='dropdown'>
                <a href='#'>Usuario<i class="fa fa-angle-down"></i></a>
                <div class='mega-menu'>
                    <div class="container">
                        <div class="item">
                            <h3>Cadastro</h3>
                            <ul>
                                <li><a href="/Cadastro/consultaID.html">Visualizar</a></li>
                                <li><a href="/Cadastro/escolha.html">Editar Dados</a></li>
                                <li><a href="/Cadastro/excluir.html">Exclusão de Conta</a></li>
                                <li><a href="/Cadastro/PHP/sair.php">Sair</a></li>
                            </ul>
                        </div> 
                    </div>
                </div>
            </li>
        </ul>
    </nav>
    <center>
        <h4>
            <?php echo "Boas Vindas ", $_SESSION['usuario'];?>
        </h4>
        <br>
        <footer>
            <p>Diretos Autorais Reservados a Carlos Afonso</p>
            <a href="https://github.com/CarlosAfonsoo"><img classe="github" src="/Cadastro/Imagens/github.png" alt="GitHub"></a>
            <a href="https://www.facebook.com/people/Carlos-Eduardo/pfbid02MJXUzUvZzoappYxeAstcbg9CFRn4Yoz6vWfVmfRwg4GZ8JnzsZJc255RBLt55kfml/"><img classe="face" src="/Cadastro/Imagens/facebook.png" alt="Facebook"></a>
            <a href="https://www.instagram.com/carlosphpdeveloper/"><img class="insta" src="/Cadastro/Imagens/instagram.png" alt="Instagram"></a>
        </footer>
    </center>
</body>
    <!-- todos o direitos autorais para Carlos Afonso -->
</html>
