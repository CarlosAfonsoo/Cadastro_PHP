<?php
    session_start();
    include("conexao.php");
    
    $Nome = $_POST['Nome'];
    $Senha = $_POST['Senha'];
    $_SESSION['usuario'] = $Nome;
    
    if(empty($Nome || $Senha)){
        header("location: \Cadastro\index.html");
        exit;

    }else{
        $sql = "SELECT `Nome`, `Senha` FROM `cadastro` WHERE Nome = '$Nome' AND Senha = '$Senha'";
        $resultado = mysqli_query($conexao,$sql);
        $registro = mysqli_fetch_array($resultado);

        $BancoNome = $registro['Nome'];
        $BancoSenha = $registro['Senha'];

        if(empty($BancoNome || $BancoSenha)){

            header("location: \Cadastro\index.html");
            mysqli_close($conexao);
            exit;
            
        }

        elseif($BancoNome == $Nome || $BancoSenha == $Senha ) {
            
            header("location: \Cadastro\PHP\Home.php");
            mysqli_close($conexao);
            exit;

        }else{

            header("location: \Cadastro\index.html");
            mysqli_close($conexao);
            exit;
        }
        
    }
?>