<?php
    session_start();
    include("conexao.php");

    $id = $_POST['ID'];
    $Nome = $_POST['Nome'];
    $Senha = $_POST['NovaSenha'];
    $confirma = $_POST['confirma'];

    if ( empty ( $id || $Nome || $Senha || $confirma )){

        header("Location: \Cadastro\RedeSenha.html");
        exit;
        // echo "Campo vaziu";
    }elseif ( $Senha != $confirma ){

        header("Location: \Cadastro\RedeSenha.html");
        exit;
        // echo "Senha diferente";
    }else{

        $sql_check = "SELECT 1 FROM `cadastro` WHERE `IDusuario` = '$id'";
        $result_check = mysqli_query($conexao,$sql_check);

        if ( mysqli_num_rows( $result_check) == 0 ){
            
            mysqli_close($conexao);
            header("Location: \Cadastro\RedeSenha.html");
            exit;
            // echo "Id não Localizado";
        }else{

            $sql_check = "SELECT 1 FROM `cadastro` WHERE `Nome` = '$Nome'";
            $result_check = mysqli_query($conexao,$sql_check);
    
            if ( mysqli_num_rows( $result_check) == 0 ){
                
                mysqli_close($conexao);
                header("Location: \Cadastro\RedeSenha.html");
                exit;
                // echo "Nome não Localizado";
            }
            else{
                $sql = "UPDATE `cadastro` SET `Senha`='$Senha' 
                WHERE `IDusuario` = '$id' AND `Nome` = '$Nome' ";
                $resultado = mysqli_query($conexao,$sql);
        
                mysqli_close($conexao);
                header("Location: \Cadastro\index.html");
                exit;
                // echo "Deu Certo";
            }
        }
    }
?>