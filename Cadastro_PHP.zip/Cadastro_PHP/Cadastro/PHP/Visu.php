<?php
//criando tabela e cabeçalho de dados:
session_start();
echo "<div class='tabela';>
        <center>
            <table border=1>";
            echo "<tr>";
                echo "<th>ID</th>";
                echo "<th>Nome</th>";
            echo "</tr>";

include_once("conexao.php"); 

$sql = "SELECT `IDusuario`, `Nome` FROM `cadastro`";
$resultado = mysqli_query($conexao,$sql) or die("Erro ao retornar dados");

while ($registro = mysqli_fetch_array($resultado))
{
    $id = $registro['IDusuario'];
    $Nome = $registro['Nome'];

    echo "<tr>";
        echo "<td>".$id."</td>";
        echo "<td>".$Nome."</td>";
    echo "</tr>";
}
mysqli_close($conexao);
echo "</table>";
echo '<br><button id="btn-blue"  class="btn btn-outline-primary"><a href="#" onclick="window.print();">imprimir</a></button>';
echo '<br><br><button id="btn-blue"  class="btn btn-outline-primary"><a href="../Home.html" </a>voltar</button>';
echo "</center><div>";
?>