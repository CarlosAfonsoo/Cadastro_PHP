<?php 
    // session_start();
    include("conexao.php");

    $nome = $_POST ['Nome'];
    $senha = $_POST ['Senha'];
    $senha2 = $_POST ['confirma'];
    $ID = $_POST ['ID'];

    if ( empty ( $nome || $senha || $ID  || $senha2) ){
        header ( "Location: /Cadastro/Cadastro.html" );
        exit;
        // echo "Campos Vaziu";

    }elseif ( $senha <> $senha2 ) {

        header ("Location: /Cadastro/Cadastro.html");
        exit;
        // echo "Senha Diferente";
    }else{

        $sql_check = "SELECT 1  FROM `cadastro` 
        WHERE `IDusuario` = '$ID' ";
        $result_check = mysqli_query($conexao,$sql_check);

        if(mysqli_num_rows($result_check) == 0){

            $sql = "INSERT INTO `cadastro`(`IDusuario`, `Nome`, `Senha`) 
            VALUES ( '$ID', '$nome', '$senha' )";
    
            $resultado = mysqli_query ( $conexao, $sql );
            mysqli_close($conexao);
            header ("Location: /Cadastro/index.html");
            exit;
        }else{
            // echo "ID já Cadastrado";
            header ("Location: /Cadastro/Cadastro.html");
            exit;
        }
    }
?>