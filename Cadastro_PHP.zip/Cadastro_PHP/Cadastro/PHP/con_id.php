<?php
    // session_start();
    include("conexao.php");

    $Nome = $_POST['Nome'];
    $Senha = $_POST['Senha'];

    if(empty( $Nome || $Senha)){

        header("Location: \Cadastro\consultaID.html");
        exit;
    }else{

        $sql = "SELECT `IDusuario`, `Nome`, `Senha` FROM `cadastro` 
        WHERE `Nome` = '$Nome' AND `Senha` = '$Senha'";

        $resultado = mysqli_query($conexao,$sql);
        $registro = mysqli_fetch_array($resultado);

        $BancoID = $registro['IDusuario'];
        $BancoNome = $registro['Nome'];
        $BancoSenha = $registro['Senha'];

        if(empty($BancoID)){

            echo "Usuario não Cadastrado";
        }else{

            echo "<div class='tabela';>
        <center>
            <table border=1>";
                echo "<tr>";
                    echo "<th>ID</th>";
                    echo "<th>Nome</th>";
                    echo "<th>Senha</th>";
                echo "</tr>";

                echo "<tr>";
                echo "<td>".$BancoID."</td>";
                echo "<td>".$BancoNome."</td>";
                echo "<td>".$BancoSenha."</td>";
                echo "</tr>";

            echo "</table>";
            echo '<br>
                <button id="btn-blue"  class="btn btn-outline-primary"><a href="#" onclick="window.print();">imprimir</a>
                </button>';
            echo '<br>
            <br><button id="btn-blue"  class="btn btn-outline-primary"><a href="../index.html" </a>voltar
            </button>';
        echo "</center>
        <div>";
        mysqli_close($conexao);
        }
    }
?>