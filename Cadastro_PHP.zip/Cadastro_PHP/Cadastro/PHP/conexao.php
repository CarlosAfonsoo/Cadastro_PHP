<?php 
    define ('Host','localhost');
    define ('Usuario','root');
    define ('SENHA','');
    define ('BD','bdconsulta');

    $conexao = mysqli_connect(Host, Usuario,SENHA, BD) or die ('Não foi possivel se conectar');
    // echo "Deu Certo"
?>