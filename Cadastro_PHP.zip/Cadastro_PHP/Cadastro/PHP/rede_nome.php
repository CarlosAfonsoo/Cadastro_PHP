<?php
    session_start();
    include("conexao.php");

    $id = $_POST['ID'];
    $Nome = $_POST['Nome'];
    $Senha = $_POST['Senha'];
    $confirma = $_POST['confirma'];

    if ( empty ( $id || $Nome || $Senha || $confirma )){

        header("Location: \Cadastro\RedeNome.html");
        exit;
        
    }elseif ( $Senha <> $confirma ){

        header("Location: \Cadastro\RedeNome.html");
        exit;

    }else{

        $sql_check = "SELECT 1 FROM `cadastro` WHERE `IDusuario` = '$id'";
        $result_check = mysqli_query($conexao,$sql_check);

        if ( mysqli_num_rows( $result_check) == 0 ){
            
            mysqli_close($conexao);
            header("Location: \Cadastro\RedeNome.html");
            exit;
        }else{

            $sql = "UPDATE `cadastro` SET `Nome`='$Nome' 
            WHERE `IDusuario` = '$id' AND `Senha` = '$Senha' ";
            $resultado = mysqli_query($conexao,$sql);
    
            mysqli_close($conexao);
            header("Location: \Cadastro\index.html");
            exit;
        }
    }
?>