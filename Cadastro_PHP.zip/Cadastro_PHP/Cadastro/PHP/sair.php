<?php
    session_start();
    session_destroy();

    header('Location: \Cadastro\index.html');
    exit();
?>